# AtividadeJavascript2
Atividade de Validações Javascript Responsive Web Development


	RM: 85708 Diogo Amaral D'andrea
	RM: 85385 Laura Luz Cabral  
	RM: 85164 Lucas Castro  
	RM: 84372 Paulo Fernando Moncaio Avelar Muniz 
	RM: 85824 Víctor Madrid Davanço 